exports.usersList = {
    user1 :{
        "id" : 1,
        "username" : "user1",
        "password" : "password",
        "name" : "user1",
        "email" : "user1@gmail.com",
        "createdAt": new Date()
    },
    user2:{
    "id" : 2,
    "username" : "user2",
    "password" : "password",
    "name" : "user2",
    "email" : "user2@gmail.com",
    "createdAt": new Date()
    }
}