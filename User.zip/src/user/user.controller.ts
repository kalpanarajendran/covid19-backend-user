import { Controller, UseGuards, Get, Param, Post, Body, Put, Delete } from '@nestjs/common';
import { UserService } from './user.service';
import { MessagePattern } from '@nestjs/microservices';
import { User } from './user.entity';
import { AuthGuard } from '../guards/AuthGuard';

@Controller()
export class UserController {
  constructor(
    private readonly userService: UserService
  ) { }

  @MessagePattern({ role: 'user', cmd: 'get' })
  getUser(data: any): any {
    console.log("data :::: ", data);
    return this.userService.findOne({ username: data.username });
  }

  @UseGuards(AuthGuard)
  @Get('getDetails/:country') 
  async getDetails(@Param('country') country:string): Promise<any> {
    return country;
  }

  @Post('createUser')
  async createUser(@Body() userDto : User) : Promise<any> {
    return this.userService.createUser(userDto);
  }

  @Get('getUser/:uname') 
  async getUserByName(@Param('uname') userName :string): Promise<any> {
    return this.userService.findOne({ username: userName });
  }

  @Get('getAllUsers')
  async getAllUsers() : Promise<any>{
    return this.userService.find({});
  }

  @Put('updateUser/:uname')
  async updateUser(@Body() userDto : User, @Param('uname') userName : string) : Promise<any>{
    return this.userService.updateUser(userName, userDto);
  }

  @Delete('deleteUser/:uname')
  async deleteUser(@Param('uname') userName : string) : Promise<any>{
    return this.userService.deleteUser(userName);
  }


}